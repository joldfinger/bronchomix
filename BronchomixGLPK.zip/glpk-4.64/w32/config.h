#define TLS __declspec(thread)
